Responsive HTML5 website template for education

Theme name:
=======================================================================
College Green

Theme version:
=======================================================================
v1.5.2

Release Date:
=======================================================================
26 Nov 2015

Author: 
=======================================================================
Xiaoying Riley at 3rd Wave Media

Contact:
=======================================================================
Web: http://themes.3rdwavemedia.com/
Email: themes@3rdwavemedia.com
Facebook: https://www.facebook.com/3rdwavethemes/
Twitter: 3rdwave_themes
