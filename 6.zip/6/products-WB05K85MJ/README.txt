/*------------------------------------------------------------------
Project:	HighLand
Version:	1.2
Created: 		18/10/2013
Last change:	26/11/2013
-------------------------------------------------------------------*/

=====================
THE HIGHLAND TEMPLATE
=====================

CREDITS

1. Font Awesome

URL: http://fontawesome.io/
AUTHOR: Dave Gandy
LICENSE: MIT License

2. Showcase

URL: http://www.pixeden.com/psd-web-elements/responsive-showcase-psd
AUTHOR: Pixeden.com
LICENSE: Royalty free for use in both personal and commercial projects

3. Pictures: 

Showcase: 

URL: http://www.flickr.com/photos/8106459@N07/3060682780/sizes/o/in/photostream/
AUTHOR: David-O
LICENSE: Creative Commons

Others:

URL: http://www.flickr.com/photos/xjrlokix/
AUTHOR: Ben Fredericson
LICENSE: Creative Commons

4. CSS Animation

URL: hhttps://daneden.me/animate/
AUTHOR: Dan Eden
LICENSE: MIT license

6. Scroll to top script

URL: http://www.dynamicdrive.com/dynamicindex3/scrolltop.htm
AUTHOR: Dynamic Drive
LICENSE: http://www.dynamicdrive.com/notice.htm

=========
CHANGELOG
=========

Version 1.2 - 26/11/2013

1. IMPROVED: Profile page redesign
2. NEW: Email and PM contact forms on the Profile page
3. NEW: Avatar upload form on the Profile page
4. NEW: Lost password form on the Sign In page
5. NEW: Profile Edit page added
6. NEW: PM Inbox Page added
7. NEW: PM Dialogs Page added
8. UPDATED: Twitter Bootstrap 3.0.2
9. REMOVED: Panorama showcase removed. Support upon request.

Version 1.1 - 23/11/2013

1. NEW: Panorama showcase added
2. NEW: Scroll to top plugin added


