### Changelogs

*Note: If you have any question, please feel free to [contact me](https://wrapbootstrap.com/user/arousing), I’ll be glad to help*

**VERSION 3.0.0** (05/22/2015)

*A BIG update to improve quality of Flatify admin!*

Note: From v3.0.0, LESS css is no longer supported as the coming Bootstrap 4 will use Sass css as well.

Completely rewrite the admin template

* Feat: Add full calendar
* Feat: Upgrade all Bower components to latest version, including angular 1.5.x
* Feat: Upgrade all NPM packages to latest version
* Feat: Add layout options
* Feat: Replace Grunt with Gulp since it's faster
* Docs: Update documentation
* And much more

---

**VERSION 2.3.0** (12/30/2015)

* Feat: Upgrade angular-bootstrap to 0.14.x
* Feat: Upgrade font-awesome to 4.5.x
* Feat: Upgrade bower components to latest version, including seiyria-bootstrap-slider (5.3.x), angular-loading-bar (0.8.x), angular-scroll (1.0.x), angular-translate (2.8.x)
* Fix: Update bootstrap fonts to fix missing font file error
* Chore: remove deprecated box-sizing mixin
* Chore: Remove jquery-spinner
* Chore: Update NPM packages to latest version

**VERSION 2.2.0** (10/09/2015)

* Feat: Add LESS CSS support.

**VERSION 2.1.1** (10/06/2015)

* Feat: Upgrade bower components to latest version.
* Fix: Fix a Typo
* Refactor: Refactor some JS, HTML code 


**VERSION 2.1.0** (09/15/2015)

* Feat: Upgrade bower components to latest version, including angular to 1.4.x, angular-bootstrap (0.13.x)...
* Feat: Switch from custom i18n module to angular-translate
* Feat: Upgrade NPM packages to latest version. Didn't upgrade grunt-contrib-connect to 0.11.x because it breaks the task


**VERSION 2.0.0** (05/15/2015)

* Feat: Competely rewrite the app based on John Papa's [Angular Style Guide](https://github.com/johnpapa/angular-styleguide)
* Feat: Upgrade plugins to latest version, including angular (1.3.x), angular-bootstrap (0.13.x), angular-scroll (0.7.x)
* Refactor: Re-write the template with plain JavaScript, I realize CoffeeScript is just my personal preference, sorry
* Chore: Clean things up, remove holderjs, underscorejs

---

**VERSION 1.4.0** (04/20/2015)

* Feat: Upgrade AngularJS to 1.3.x
* Feat: Upgrade plugin to latest version, including seiyria-bootsstrap-slider (4.8.x), textAngular (1.3.x), angular-loading-bar (0.7.x)
* Chore: Remove Task App

**VERSION 1.3.1** (02/28/2015)

* Feat: Update Bower packages
* Fix: Reset scroll position on a route change.
* Docs: Update documentation style.

**VERSION 1.3.0** (01/28/2015)

* Feat: Upgrade ui-bootstrap to 0.12.x
* Feat: Upgrade Bower packages to latest version. Including font-awesome (4.3.x), seiyria-bootstrap-slider (4.4.x), morris.js (0.5.x), textAngular (1.3.x), weather-icons (1.3.x)
* Feat: Upgrade NPM packages to latest version
* Feat: Update checkbox style
* Feat: Add changelog
* Fix: Update media component markup for bootstrap 3.3
* Fix: Remove link focus underline style
* Docs: Update documentation
* Chore: Update task content

**VERSION 1.2.0** (11/14/2014)

* Feat: Upgrade Bootstrap to 3.3x
* Feat: Update angular-ui Bootstrap to 0.11.x
* Feat: Add loader
* Feat: Upgrade "seiyria-bootstrap-slider" to latest version, i.e. 4.0.1
* Feat: Upgrade weather-icons to latest version, i.e. 1.2.1
* Feat: Upgrade Font-awesome, Toastr, jQuery steps to the latest version
* Fix: Hide select arrow in Firefox 30+, thanks @calidae
* Fix: Update table markup, remove buggy responsive table by Zurb
* Chore: Update index.html to make it HTML5 valid
* Chore: Allow you also to run it with "grunt serve"
* Chore: Clean up

**VERSION 1.1.0** (08/20/2014)

* Feat: Upgrade Bootstrap to 3.2.x
* Feat: Better radio, checkbox, select and rating
* Feat: Add pricing table
* Feat: Optimize timeline on mobile
* Feat: Update font awesome to 4.1.x
* Feat: Allow user to add plain JS in scripts folder
* Fix: Fix morris tooltip overlay on sidebar menu bug
* Fix: Fix a typo
* Chore: Update tooltip, popover option to avoid weird shift
* Chore: Update i18n data
* Chore: Update table markup
* Chore:  Clean up blank page

**VERSION 1.0.1** (05/20/2014)

* Fix: Fix textAngular 404 error caused by its new version
* Chore: Clean up bower.json file